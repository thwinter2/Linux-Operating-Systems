double log(double);
double pow(double, int);
double expdev(double);
