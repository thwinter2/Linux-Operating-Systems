void setschedclass(int);
int getschedclass(void);
extern int sched_type;
#define EXPDISTSCHED  1
#define LINUXSCHED  2
